const express = require("express");
const mongoose = require("mongoose");
const sinhvien = require("./sinhvienModal");

// Tạo đối tượng
const app = express();

// Kết nối cơ sở dữ liệu
mongoose.connect("mongodb://localhost:27017/AND103", {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Đã kết nối thành công với MongoDB');
}).catch((err) => {
  console.log(err); // In ra lỗi
});

// Khi người dùng gọi localhost => đọc dữ liệu từ cơ sở dữ liệu
app.get('/sinhvien', async (req, res) => {
  try {
    const sinhviens = await sinhvien.find();
    res.json(sinhviens);
    console.log(sinhviens);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Không kết nối được với server' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log('Server đang chạy ở cổng 3000');
});
