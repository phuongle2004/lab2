const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const sinhvienSchema = new Schema({
    name: { type: String, required: true },
    age: { type: Number, required: true },
    // Định nghĩa các trường khác ở đây
});

module.exports = mongoose.model('SinhVien', sinhvienSchema);
